
package jobscheduler;

public class Job {
    private int id;
    private int priority;
    private int processingTime;
    private int arrivalTime;
    private int startTime;
    private int endTime;
    
    public Job() {
        this.id = 0;
        this.priority = 0;
        this.processingTime = 0;
        this.arrivalTime = 0;
        this.startTime = 0;
        this.endTime = 0;
    }
    
    public Job(int id, int priority, int processingTime, int arrivalTime) {
        this.id = id;
        this.priority = priority;
        this.processingTime = processingTime;
        this.arrivalTime = arrivalTime;
        this.startTime = 0;
        this.endTime = 0;
    }
    
    public int getId() {
        return id;
    }
    
    public void setId(int id) {
        this.id = id;
    }
    
    public int getPriority() {
        return priority;
    }
    
    public void setPriority(int priority) {
        this.priority = priority;
    }
    
    public int getProcessingTime() {
        return processingTime;
    }
    
    public void setProcessingTime(int processingTime) {
        this.processingTime = processingTime;
    }
    
    public int getArrivalTime() {
        return arrivalTime;
    }
    
    public void setArrivalTime(int arrivalTime) {
        this.arrivalTime = arrivalTime;
    }
    
    public int getStartTime() {
        return startTime;
    }
    
    public void setStartTime(int startTime) {
        this.startTime = startTime;
    }
    
    public int getEndTime() {
        return endTime;
    }
    
    public void setEndTime(int endTime) {
        this.endTime = endTime;
    }
}
