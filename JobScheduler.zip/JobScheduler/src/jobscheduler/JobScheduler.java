/*
Author: Stephanie Harders
 */
package jobscheduler;

import java.util.PriorityQueue;

public class JobScheduler {
    private PriorityQueue<Job> jobQueue;
    
    public JobScheduler() {
        jobQueue = new PriorityQueue<>((j1, j2) -> {
            if (j1.getPriority() != j2.getPriority()) {
                return j2.getPriority() - j1.getPriority();
            } else {
                return j1.getArrivalTime() - j2.getArrivalTime();
            }
        });
    }
    
    public void addJob(Job job) {
        jobQueue.add(job);
    }
    
    public boolean hasJobs() {
        return !jobQueue.isEmpty();
    }
    
    public Job getNextJob() {
        return jobQueue.poll();
    }
}
