
package jobscheduler;

import java.util.Random;

public class JobSchedulingSim {
public static void main(String[] args) {
    JobScheduler scheduler = new JobScheduler();
    Random random = new Random();
    int NumberOfJobs = 20;
    int MaxProcessingTime = 10; // max processing time in seconds
    int MaxPriority = 11;

    // Generate jobs with random properties
    for (int i = 0; i < NumberOfJobs; i++) {
        int priority = random.nextInt(MaxPriority);
        int processingTime = random.nextInt(MaxProcessingTime) + 1; // add 1 to avoid 0 processing time
        int ArrivalTime = random.nextInt(500) + 1; // add 1 to avoid 0 arrival time
        Job job = new Job();
        job.setId(i);
        job.setPriority(priority);
        job.setProcessingTime(processingTime * 1000); // convert seconds to milliseconds
        job.setArrivalTime(ArrivalTime * 1000); // convert seconds to milliseconds
        scheduler.addJob(job);
    }

    // Execute jobs and measure execution time
 int currentTime = 0;
while (scheduler.hasJobs()) {
    Job job = scheduler.getNextJob();
    int waitTime = currentTime - job.getArrivalTime();
    if (waitTime < 0) {
        waitTime = 0;
    }
    System.out.println("Executing job " + job.getId() + " with priority " + job.getPriority() +
            " and processing time " + job.getProcessingTime()/1000 + " seconds, wait time = " + waitTime + " seconds");
    job.setStartTime(currentTime);
    try {
        Thread.sleep(job.getProcessingTime());
    } catch (InterruptedException e) {
        e.printStackTrace();
    }
    job.setEndTime(currentTime + job.getProcessingTime());
    currentTime += job.getProcessingTime();
    if (job.getEndTime() < 0) {
        job.setEndTime(0);
    }
    System.out.println("Job " + job.getId() + " completed at time " + job.getEndTime()/1000 + " seconds");
}

    }
}


